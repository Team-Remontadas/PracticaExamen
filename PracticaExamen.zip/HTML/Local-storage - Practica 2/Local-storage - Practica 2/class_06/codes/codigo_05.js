var btnGuardar = document.getElementById("btnGuardar");
var btnMostrar = document.getElementById("btnMostrar");
var txtNomb = document.getElementById("txtNomb");
var txtNac = document.getElementById("txtNac");
var txtMonto = document.getElementById("txtMonto");
var txtCantDatos = document.getElementById("txtCantDatos");
var resultados = document.getElementById("Datos");

// Cambiamos la URL a la de tu servidor Flask que corre en el localhost puerto 5001
//var url = "http://localhost:5001/interested"; // Cambio clave aquí

btnGuardar.addEventListener("click", function () {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 201) {
            var resul = JSON.parse(xhr.responseText);
            // Almacenar el token en localStorage
            localStorage.setItem("userToken", resul.data.interested.token);
            alert("Registro exitoso. Token guardado.");
        } else if (xhr.readyState == 4) {
            alert("Hubo un problema con el registro.");
        }
    };
    var data = JSON.stringify({
        "name": txtNomb.value,
        "fechaNac": txtNac.value,
        "monto": txtMonto.value,
        "cantDados": txtCantDatos.value

    });
    xhr.send(data);
});
